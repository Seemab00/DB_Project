package cakeordermanagementsystem;

public class CakeOrderManagementSystem 
{
    public static void main(String[] args) 
    {

    }
}
